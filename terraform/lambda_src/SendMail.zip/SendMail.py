import boto3
import json

# Amazon SES client 생성
ses_client = boto3.client('ses')

def send_email(email_address, message):
    # 이메일 본문
    email_body = message

    # 이메일 보내기
    response = ses_client.send_email(
        Destination={
            'ToAddresses': [
                email_address
            ],
        },
        Message={
            'Body': {
                'Text': {
                    'Charset': 'UTF-8',
                    'Data': email_body,
                },
            },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': 'Flower53 공모전 등록',
            },
        },
        Source='contest@flower53.site',
    )

    return response

def handler(event, context):
    print(event)
    message = json.loads(event['Records'][0]['Sns']['Message'])
    key = message['Records'][0]['s3']['object']['key']
    mail_split = key.split("/")[1].split("-")[:2]
    email_address = "@".join(mail_split)
    print(email_address)


    # message = sns_message_json['message']
    message = "안녕하세요 꽃보러오삼의 봄꽃 사진 공모전에 등록해 주셔서 감사합니다. \n\n 꽃보러오삼 : http://www.flower53.site"

    # 이메일 보내기
    response = send_email(email_address, message)

    print(response)
    